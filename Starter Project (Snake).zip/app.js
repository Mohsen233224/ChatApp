const serviceCards = document.querySelectorAll('.service-card');

serviceCards.forEach(card => {
  
  card.addEventListener('click', () => {
    
    card.style.transform = 'scale(.95)';
    
    setTimeout(() => {
      card.style.transform = 'scale(1)';
    }, 150);
    
  });
  
});

const payButton = document.querySelector('.card-bottom button');

payButton.addEventListener('click', () => {
  alert('تم تحويلك لصفحة الدفع');
});